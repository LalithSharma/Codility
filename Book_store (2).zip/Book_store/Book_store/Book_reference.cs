﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Book_store
{
    internal class Book_reference
    {
    }
   public class Book_dic
    {
        public string BookID { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string Genre { get; set; }
        public string Price { get; set; }
        public string Published_date { get; set; }
        public string Description { get; set; }
    }
}
